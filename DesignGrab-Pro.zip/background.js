// Click extension icon → inject the side panel into the page
chrome.action.onClicked.addListener((tab) => {
  if (!tab.id) return;
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['panel.js'],
  });
});

// Handle license API calls from panel.js
// (Background worker can call external APIs without CORS restrictions)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'activate-license') {
    fetch('https://api.lemonsqueezy.com/v1/licenses/activate', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        license_key: msg.licenseKey,
        instance_name: 'DesignGrab-' + msg.instanceId,
      }),
    })
    .then(r => r.json())
    .then(data => sendResponse({ ok: true, data }))
    .catch(err => sendResponse({ ok: false, error: err.message }));
    return true; // keep channel open for async response
  }

  if (msg.type === 'validate-license') {
    fetch('https://api.lemonsqueezy.com/v1/licenses/validate', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        license_key: msg.licenseKey,
        instance_id: msg.instanceId,
      }),
    })
    .then(r => r.json())
    .then(data => sendResponse({ ok: true, data }))
    .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }
});
