// Click extension icon → inject the side panel into the page
chrome.action.onClicked.addListener((tab) => {
  if (!tab.id) return;
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['panel.js'],
  });
});
