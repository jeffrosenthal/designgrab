(function() {
  'use strict';

  // ── Toggle: click again to close ──
  const existing = document.getElementById('designgrab-host');
  if (existing) {
    clearAllHighlights();
    stopPicker();
    existing.remove();
    document.body.style.marginRight = '';
    const hlStyle = document.getElementById('dg-hl-style');
    if (hlStyle) hlStyle.remove();
    return;
  }

  // ── Inject highlight animation style into page ──
  const hlStyle = document.createElement('style');
  hlStyle.id = 'dg-hl-style';
  hlStyle.textContent = `
    @keyframes dg-pulse {
      0%, 100% { background: rgba(167, 139, 250, 0.08); }
      50% { background: rgba(167, 139, 250, 0.22); }
    }
  `;
  document.head.appendChild(hlStyle);

  // ── Create host + shadow DOM (isolates styles from page) ──
  const host = document.createElement('div');
  host.id = 'designgrab-host';
  host.style.cssText = 'position:fixed;top:0;right:0;width:360px;height:100vh;z-index:2147483647;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;';
  document.body.appendChild(host);
  document.body.style.marginRight = '360px';

  const shadow = host.attachShadow({ mode: 'closed' });

  // ── Styles ──
  const style = document.createElement('style');
  style.textContent = `
    * { margin:0; padding:0; box-sizing:border-box; }
    :host { all: initial; }
    .panel {
      width: 360px; height: 100vh; overflow-y: auto;
      background: #0f0f0f; color: #e4e4e7;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-size: 13px; line-height: 1.5;
      border-left: 1px solid #27272a;
    }
    .panel::-webkit-scrollbar { width: 5px; }
    .panel::-webkit-scrollbar-thumb { background: #3f3f46; border-radius: 3px; }

    .header {
      padding: 14px 16px; border-bottom: 1px solid #27272a;
      display: flex; align-items: center; justify-content: space-between;
      position: sticky; top: 0; background: #0f0f0f; z-index: 10;
    }
    .header-left h1 { font-size: 14px; font-weight: 700; color: #fff; }
    .header-left .site { font-size: 10px; color: #52525b; margin-top: 1px; }
    .header-right { display: flex; gap: 6px; align-items: center; }
    .close-btn {
      width: 28px; height: 28px; background: #1c1c1e; border: 1px solid #27272a;
      border-radius: 6px; color: #71717a; font-size: 16px; cursor: pointer;
      display: flex; align-items: center; justify-content: center; transition: all 0.15s;
    }
    .close-btn:hover { background: #27272a; color: #fff; }
    .close-btn.active { background: #a78bfa; color: #000; border-color: #a78bfa; }

    .section { padding: 12px 16px; border-bottom: 1px solid #1c1c1e; }
    .section-head {
      display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;
    }
    .section-title {
      font-size: 10px; font-weight: 700; text-transform: uppercase;
      letter-spacing: 0.8px; color: #52525b;
    }
    .section-count { font-size: 10px; color: #3f3f46; }

    .palette { display: flex; flex-wrap: wrap; gap: 5px; }
    .swatch {
      width: 36px; height: 36px; border-radius: 6px; cursor: pointer;
      border: 1px solid #27272a; position: relative;
      transition: transform 0.12s, box-shadow 0.12s;
    }
    .swatch:hover {
      transform: scale(1.2); box-shadow: 0 4px 16px rgba(0,0,0,0.5); z-index: 10;
    }
    .swatch-label {
      position: absolute; bottom: -16px; left: 50%; transform: translateX(-50%);
      font-size: 8px; color: #52525b; white-space: nowrap;
      opacity: 0; transition: opacity 0.12s; pointer-events: none;
    }
    .swatch:hover .swatch-label { opacity: 1; }
    .swatch.picked {
      outline: 3px solid #fff; outline-offset: 2px;
      animation: swatch-pulse 0.6s ease-in-out 3;
    }
    @keyframes swatch-pulse {
      0%, 100% { outline-color: #fff; }
      50% { outline-color: #a78bfa; }
    }

    .font-item { padding: 6px 0; border-bottom: 1px solid #1c1c1e; }
    .font-item:last-child { border-bottom: none; }
    .font-name {
      font-size: 13px; font-weight: 600; color: #fff; cursor: pointer;
      transition: color 0.2s;
    }
    .font-name:hover { color: #a78bfa; }
    .font-name.picked { color: #4ade80; }
    .font-meta { font-size: 10px; color: #3f3f46; margin-top: 2px; }
    .font-meta span {
      background: #1c1c1e; padding: 1px 5px; border-radius: 3px; margin-right: 4px;
    }

    .spacing-row { display: flex; flex-wrap: wrap; gap: 4px; }
    .spacing-chip {
      background: #1c1c1e; border: 1px solid #27272a; border-radius: 4px;
      padding: 3px 7px; font-size: 10px; font-family: monospace;
      color: #71717a; cursor: pointer; transition: background 0.12s;
    }
    .spacing-chip:hover { background: #27272a; color: #fff; }

    .export-section { padding: 12px 16px; border-bottom: 1px solid #1c1c1e; }
    .export-buttons { display: flex; gap: 6px; }
    .export-btn {
      flex: 1; padding: 8px 0; background: #1c1c1e; border: 1px solid #27272a;
      border-radius: 6px; color: #a1a1aa; font-size: 10px; font-weight: 600;
      cursor: pointer; text-align: center; transition: all 0.12s;
    }
    .export-btn:hover { background: #27272a; border-color: #a78bfa; color: #fff; }
    .export-btn.locked {
      opacity: 0.4; cursor: default;
    }
    .export-btn.locked:hover { background: #1c1c1e; border-color: #27272a; color: #a1a1aa; }

    .license-section { padding: 12px 16px; border-bottom: 1px solid #1c1c1e; }
    .license-input {
      width: 100%; padding: 7px 10px; background: #1c1c1e; border: 1px solid #27272a;
      border-radius: 6px; color: #e4e4e7; font-size: 12px; font-family: monospace;
      outline: none; margin-bottom: 6px;
    }
    .license-input:focus { border-color: #a78bfa; }
    .license-row { display: flex; gap: 6px; }
    .license-btn {
      padding: 7px 14px; background: #a78bfa; color: #000; border: none;
      border-radius: 6px; font-size: 11px; font-weight: 700; cursor: pointer;
      transition: background 0.15s;
    }
    .license-btn:hover { background: #8b5cf6; }
    .license-msg { font-size: 10px; margin-top: 4px; min-height: 14px; }
    .license-link {
      display: inline-block; margin-top: 6px; font-size: 11px;
      color: #a78bfa; text-decoration: none;
    }
    .license-link:hover { text-decoration: underline; }
    .pro-badge {
      display: flex; align-items: center; gap: 10px;
      font-size: 11px; color: #4ade80; font-weight: 600;
    }
    .deactivate-btn {
      padding: 3px 10px; background: transparent; border: 1px solid #27272a;
      border-radius: 4px; color: #52525b; font-size: 10px; cursor: pointer;
      transition: all 0.15s;
    }
    .deactivate-btn:hover { border-color: #ef4444; color: #ef4444; }

    .toast {
      position: fixed; bottom: 16px; left: 50%; transform: translateX(-50%) translateY(30px);
      background: #a78bfa; color: #000; font-size: 11px; font-weight: 600;
      padding: 5px 14px; border-radius: 16px; opacity: 0;
      transition: all 0.2s ease; pointer-events: none; z-index: 100;
    }
    .toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }

    .loading {
      display: flex; flex-direction: column; align-items: center;
      justify-content: center; padding: 80px 20px; gap: 10px;
    }
    .spinner {
      width: 20px; height: 20px; border: 2px solid #27272a;
      border-top: 2px solid #a78bfa; border-radius: 50%;
      animation: spin 0.6s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    .loading-text { font-size: 11px; color: #52525b; }

    .hint {
      padding: 8px 16px; font-size: 10px; color: #3f3f46;
      text-align: center; border-top: 1px solid #1c1c1e;
    }

    /* Help overlay */
    .help-overlay {
      position: absolute; top: 0; left: 0; width: 100%; height: 100%;
      background: #0f0f0f; z-index: 50; overflow-y: auto;
      opacity: 0; transform: translateY(12px);
      transition: opacity 0.25s ease, transform 0.25s ease;
      pointer-events: none;
    }
    .help-overlay.open {
      opacity: 1; transform: translateY(0); pointer-events: auto;
    }
    .help-overlay::-webkit-scrollbar { width: 5px; }
    .help-overlay::-webkit-scrollbar-thumb { background: #3f3f46; border-radius: 3px; }

    .help-header {
      padding: 14px 16px; border-bottom: 1px solid #27272a;
      display: flex; align-items: center; justify-content: space-between;
      position: sticky; top: 0; background: #0f0f0f; z-index: 10;
    }
    .help-header h2 {
      font-size: 14px; font-weight: 700; color: #fff;
    }
    .help-content { padding: 16px; }

    .help-card {
      background: #18181b; border: 1px solid #27272a; border-radius: 10px;
      padding: 16px; margin-bottom: 12px;
      transition: border-color 0.2s;
    }
    .help-card:hover { border-color: #3f3f46; }
    .help-card-header {
      display: flex; align-items: center; gap: 10px; margin-bottom: 8px;
    }
    .help-icon {
      width: 32px; height: 32px; border-radius: 8px;
      display: flex; align-items: center; justify-content: center;
      font-size: 16px; flex-shrink: 0;
    }
    .help-card-header h3 {
      font-size: 13px; font-weight: 700; color: #fff;
    }
    .help-card p {
      font-size: 12px; color: #a1a1aa; line-height: 1.6; margin: 0;
    }
    .help-card .key {
      display: inline-block; padding: 1px 6px; background: #27272a;
      border: 1px solid #3f3f46; border-radius: 4px;
      font-size: 10px; font-family: monospace; color: #e4e4e7;
      vertical-align: middle;
    }
    .help-card .dot {
      display: inline-block; width: 8px; height: 8px; border-radius: 50%;
      vertical-align: middle; margin: 0 2px;
    }

    .help-footer {
      padding: 12px 16px; text-align: center; font-size: 10px; color: #3f3f46;
      border-top: 1px solid #1c1c1e;
    }
    .help-footer a { color: #a78bfa; text-decoration: none; }
    .help-footer a:hover { text-decoration: underline; }
  `;
  shadow.appendChild(style);

  // ── Panel HTML ──
  const panel = document.createElement('div');
  panel.className = 'panel';
  panel.innerHTML = `
    <div class="loading" id="dg-loading">
      <div class="spinner"></div>
      <div class="loading-text">Scanning page...</div>
    </div>
    <div id="dg-results" style="display:none">
      <div class="header">
        <div class="header-left">
          <h1>DesignGrab</h1>
          <div class="site" id="dg-site"></div>
        </div>
        <div class="header-right">
          <button class="close-btn" id="dg-help" title="Help" style="font-size:14px;font-weight:700;">?</button>
          <button class="close-btn" id="dg-picker" title="Pick element from page">&#8982;</button>
          <button class="close-btn" id="dg-close">&times;</button>
        </div>
      </div>
      <div class="section">
        <div class="section-head">
          <div class="section-title">Colors</div>
          <div class="section-count" id="dg-color-count"></div>
        </div>
        <div class="palette" id="dg-palette"></div>
      </div>
      <div class="section">
        <div class="section-head">
          <div class="section-title">Typography</div>
          <div class="section-count" id="dg-font-count"></div>
        </div>
        <div id="dg-fonts"></div>
      </div>
      <div class="section">
        <div class="section-head">
          <div class="section-title">Spacing</div>
          <div class="section-count" id="dg-spacing-count"></div>
        </div>
        <div class="spacing-row" id="dg-spacing"></div>
      </div>
      <div class="export-section">
        <div class="section-head">
          <div class="section-title">Export</div>
          <div class="section-count" id="dg-pro-label">Pro</div>
        </div>
        <div class="export-buttons">
          <button class="export-btn" id="dg-css">CSS Vars</button>
          <button class="export-btn" id="dg-tailwind">Tailwind</button>
          <button class="export-btn" id="dg-json">JSON</button>
        </div>
      </div>
      <div class="license-section" id="dg-license-section">
        <div id="dg-license-ui">
          <div style="font-size:11px;color:#71717a;margin-bottom:8px;">
            Enter your license key to unlock exports.
          </div>
          <input type="text" class="license-input" id="dg-license-input"
            placeholder="Enter license key...">
          <div class="license-row">
            <button class="license-btn" id="dg-license-btn">Activate</button>
          </div>
          <div class="license-msg" id="dg-license-msg"></div>
          <a class="license-link" id="dg-buy-link" href="https://thecodingpit.lemonsqueezy.com/checkout/buy/0888d7b8-c3cb-433b-aec8-844c7fae22c2" target="_blank">
            Get a license key — $29
          </a>
        </div>
        <div id="dg-pro-badge" class="pro-badge" style="display:none;">
          Pro Active
          <button class="deactivate-btn" id="dg-deactivate">Deactivate</button>
        </div>
      </div>
      <div class="hint">Hover color to highlight on page. Click &#8982; to pick an element.</div>
    </div>
    <div class="help-overlay" id="dg-help-overlay">
      <div class="help-header">
        <h2>How to use DesignGrab</h2>
        <button class="close-btn" id="dg-help-close">&times;</button>
      </div>
      <div class="help-content">

        <div class="help-card">
          <div class="help-card-header">
            <div class="help-icon" style="background:linear-gradient(135deg,#a78bfa,#c084fc);">
              <span style="font-size:14px;">&#127912;</span>
            </div>
            <h3>Colors</h3>
          </div>
          <p>Every color on the page is extracted and shown as a swatch. <strong>Hover</strong> a swatch to see all matching elements highlighted on the page with a count. <strong>Click</strong> any swatch to copy its hex code.</p>
        </div>

        <div class="help-card">
          <div class="help-card-header">
            <div class="help-icon" style="background:linear-gradient(135deg,#60a5fa,#3b82f6);">
              <span style="font-size:14px;">Aa</span>
            </div>
            <h3>Typography</h3>
          </div>
          <p>All font families, sizes, and weights used on the page. <strong>Click</strong> a font name to copy it. Sizes and weights are shown below each font.</p>
        </div>

        <div class="help-card">
          <div class="help-card-header">
            <div class="help-icon" style="background:linear-gradient(135deg,#34d399,#10b981);">
              <span style="font-size:14px;">&#8614;</span>
            </div>
            <h3>Spacing</h3>
          </div>
          <p>Padding, margin, and gap values extracted into a clean scale. <strong>Click</strong> any value to copy it.</p>
        </div>

        <div class="help-card">
          <div class="help-card-header">
            <div class="help-icon" style="background:linear-gradient(135deg,#f472b6,#ec4899);">
              <span style="font-size:14px;">&#8982;</span>
            </div>
            <h3>Element Picker</h3>
          </div>
          <p>Click the <span class="key">&#8982;</span> button in the header to enter picker mode. Your cursor becomes a crosshair. <strong>Click any element</strong> on the page and the sidebar will scroll to its matching color and font. Press <span class="key">Esc</span> to cancel.</p>
        </div>

        <div class="help-card">
          <div class="help-card-header">
            <div class="help-icon" style="background:linear-gradient(135deg,#fbbf24,#f59e0b);">
              <span style="font-size:14px;">&#128203;</span>
            </div>
            <h3>Export</h3>
          </div>
          <p>Export the full design system as <strong>CSS Variables</strong>, <strong>Tailwind config</strong>, or <strong>JSON</strong>. Exports are copied to your clipboard, ready to paste. Requires a Pro license key.</p>
        </div>

        <div class="help-card">
          <div class="help-card-header">
            <div class="help-icon" style="background:linear-gradient(135deg,#a78bfa,#7c3aed);">
              <span style="font-size:14px;">&#9919;</span>
            </div>
            <h3>Pro License</h3>
          </div>
          <p>After purchasing, you'll receive a license key by email. Paste it in the sidebar and click <strong>Activate</strong>. Your key works on up to 2 machines. Lost your key? Check your email or visit your LemonSqueezy customer portal.</p>
        </div>

      </div>
      <div class="help-footer">
        DesignGrab v1.2 &middot; <a href="mailto:jeff@thecodingpit.com">jeff@thecodingpit.com</a>
      </div>
    </div>
    <div class="toast" id="dg-toast">Copied!</div>
  `;
  shadow.appendChild(panel);

  // ── Refs ──
  const $ = (id) => shadow.getElementById(id);

  // ── Pro state ──
  let isPro = false;

  // ── Close ──
  $('dg-close').addEventListener('click', () => {
    clearAllHighlights();
    stopPicker();
    host.remove();
    document.body.style.marginRight = '';
    const hs = document.getElementById('dg-hl-style');
    if (hs) hs.remove();
  });

  // ── Help overlay ──
  $('dg-help').addEventListener('click', () => {
    $('dg-help-overlay').classList.toggle('open');
  });
  $('dg-help-close').addEventListener('click', () => {
    $('dg-help-overlay').classList.remove('open');
  });

  // ── Toast ──
  function toast(msg) {
    const t = $('dg-toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 1200);
  }

  // ── Highlight helpers ──
  function rgbToHex(rgb) {
    const m = rgb.match(/rgba?\(\s*(\d+),\s*(\d+),\s*(\d+)/);
    if (!m) return null;
    const r = parseInt(m[1]), g = parseInt(m[2]), b = parseInt(m[3]);
    return '#' + [r,g,b].map(x => x.toString(16).padStart(2,'0')).join('');
  }

  function highlightColor(hex) {
    clearAllHighlights();
    const els = document.querySelectorAll('body *:not(#designgrab-host):not(#designgrab-host *)');
    let count = 0;
    for (const el of els) {
      try {
        const cs = getComputedStyle(el);
        const bg = rgbToHex(cs.backgroundColor);
        const fg = rgbToHex(cs.color);
        const bd = rgbToHex(cs.borderTopColor);
        if (bg === hex || fg === hex || bd === hex) {
          count++;
          el.setAttribute('data-dg-hl', '1');
          const rect = el.getBoundingClientRect();
          const overlay = document.createElement('div');
          overlay.className = 'dg-highlight-overlay';
          overlay.style.cssText =
            'position:fixed;top:' + rect.top + 'px;left:' + rect.left + 'px;' +
            'width:' + rect.width + 'px;height:' + rect.height + 'px;' +
            'border:2px solid #a78bfa;pointer-events:none;z-index:2147483646;' +
            'border-radius:2px;animation:dg-pulse 1s ease-in-out infinite;';
          document.body.appendChild(overlay);
        }
      } catch(e) {}
    }
    return count;
  }

  function clearAllHighlights() {
    document.querySelectorAll('[data-dg-hl]').forEach(el => {
      el.removeAttribute('data-dg-hl');
    });
    document.querySelectorAll('.dg-highlight-overlay').forEach(el => el.remove());
  }

  // ── Element Picker ──
  let pickerActive = false;
  let pickerOverlay = null;
  let pickerHighlightBox = null;
  let pickerHoverEl = null;

  function startPicker() {
    pickerActive = true;
    $('dg-picker').classList.add('active');

    pickerOverlay = document.createElement('div');
    pickerOverlay.id = 'dg-picker-overlay';
    pickerOverlay.style.cssText =
      'position:fixed;top:0;left:0;width:calc(100vw - 360px);height:100vh;' +
      'z-index:2147483646;cursor:crosshair;';
    document.body.appendChild(pickerOverlay);

    pickerOverlay.addEventListener('mousemove', onPickerMove);
    pickerOverlay.addEventListener('click', onPickerClick);
  }

  function stopPicker() {
    pickerActive = false;
    const btn = $('dg-picker');
    if (btn) btn.classList.remove('active');
    clearPickerHighlight();
    if (pickerOverlay) {
      pickerOverlay.remove();
      pickerOverlay = null;
    }
    pickerHoverEl = null;
  }

  function clearPickerHighlight() {
    if (pickerHighlightBox) {
      pickerHighlightBox.remove();
      pickerHighlightBox = null;
    }
  }

  function onPickerMove(e) {
    pickerOverlay.style.pointerEvents = 'none';
    const el = document.elementFromPoint(e.clientX, e.clientY);
    pickerOverlay.style.pointerEvents = 'auto';

    if (!el || el === pickerHoverEl || el.id === 'designgrab-host' || el.closest && el.closest('#designgrab-host')) {
      return;
    }

    pickerHoverEl = el;
    clearPickerHighlight();

    const rect = el.getBoundingClientRect();
    pickerHighlightBox = document.createElement('div');
    pickerHighlightBox.style.cssText =
      'position:fixed;top:' + rect.top + 'px;left:' + rect.left + 'px;' +
      'width:' + rect.width + 'px;height:' + rect.height + 'px;' +
      'border:2px solid #a78bfa;background:rgba(167,139,250,0.1);' +
      'pointer-events:none;z-index:2147483646;border-radius:2px;';
    document.body.appendChild(pickerHighlightBox);
  }

  function onPickerClick(e) {
    e.preventDefault();
    e.stopPropagation();

    pickerOverlay.style.pointerEvents = 'none';
    const el = document.elementFromPoint(e.clientX, e.clientY);
    pickerOverlay.style.pointerEvents = 'auto';

    if (!el) { stopPicker(); return; }

    let cs;
    try { cs = getComputedStyle(el); } catch(err) { stopPicker(); return; }

    // Extract color (prefer non-black background, fall back to text color)
    const bgHex = rgbToHex(cs.backgroundColor);
    const fgHex = rgbToHex(cs.color);
    const transparent = bgHex === '#000000' && cs.backgroundColor.includes('0)');
    const targetColor = (!transparent && bgHex && bgHex !== '#000000') ? bgHex : fgHex;

    // Extract font
    const targetFont = cs.fontFamily.split(',')[0].trim().replace(/['"]/g, '');

    let found = [];

    // Scroll to matching swatch in sidebar
    if (targetColor) {
      const swatches = shadow.querySelectorAll('.swatch');
      for (const sw of swatches) {
        const swatchHex = rgbToHex(sw.style.backgroundColor);
        if (swatchHex === targetColor) {
          sw.scrollIntoView({ behavior: 'smooth', block: 'center' });
          sw.classList.add('picked');
          setTimeout(() => sw.classList.remove('picked'), 2000);
          found.push(targetColor);
          break;
        }
      }
    }

    // Scroll to matching font
    if (targetFont) {
      const fontNames = shadow.querySelectorAll('.font-name');
      for (const fn of fontNames) {
        if (fn.textContent.toLowerCase() === targetFont.toLowerCase()) {
          fn.scrollIntoView({ behavior: 'smooth', block: 'center' });
          fn.classList.add('picked');
          setTimeout(() => fn.classList.remove('picked'), 2000);
          found.push(targetFont);
          break;
        }
      }
    }

    if (found.length) {
      toast(found.join(' + '));
    } else {
      toast('No match found');
    }

    stopPicker();
  }

  // Escape key cancels picker
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && pickerActive) stopPicker();
  });

  // Wire up picker button
  $('dg-picker').addEventListener('click', () => {
    if (pickerActive) stopPicker();
    else startPicker();
  });

  // ── License check ──
  async function checkLicense() {
    try {
      const stored = await chrome.storage.sync.get([
        'dg_license_key', 'dg_instance_id', 'dg_license_valid', 'dg_license_checked'
      ]);

      // Cached valid result from last 24 hours
      if (stored.dg_license_valid && stored.dg_license_checked) {
        const hoursSince = (Date.now() - stored.dg_license_checked) / (1000 * 60 * 60);
        if (hoursSince < 24) {
          isPro = true;
          updateProUI();
          return;
        }
      }

      // Have a stored key — re-validate
      if (stored.dg_license_key && stored.dg_instance_id) {
        const resp = await new Promise(resolve => {
          chrome.runtime.sendMessage({
            type: 'validate-license',
            licenseKey: stored.dg_license_key,
            instanceId: stored.dg_instance_id,
          }, resolve);
        });
        if (resp && resp.ok && resp.data && resp.data.valid) {
          isPro = true;
          await chrome.storage.sync.set({ dg_license_valid: true, dg_license_checked: Date.now() });
        } else {
          isPro = false;
          await chrome.storage.sync.set({ dg_license_valid: false });
        }
      }
    } catch(e) {
      // If chrome.runtime is unavailable, check cached state only
      try {
        const stored = await chrome.storage.sync.get(['dg_license_valid']);
        if (stored.dg_license_valid) isPro = true;
      } catch(e2) {}
    }
    updateProUI();
  }

  function updateProUI() {
    const licenseUI = $('dg-license-ui');
    const proBadge = $('dg-pro-badge');
    const proLabel = $('dg-pro-label');
    if (licenseUI) licenseUI.style.display = isPro ? 'none' : 'block';
    if (proBadge) proBadge.style.display = isPro ? 'flex' : 'none';
    if (proLabel) proLabel.textContent = isPro ? 'Pro' : 'Pro (locked)';

    ['dg-css', 'dg-tailwind', 'dg-json'].forEach(id => {
      const btn = $(id);
      if (!btn) return;
      if (isPro) {
        btn.classList.remove('locked');
        btn.title = '';
      } else {
        btn.classList.add('locked');
        btn.title = 'Pro only — activate a license key';
      }
    });
  }

  // Activate button
  $('dg-license-btn').addEventListener('click', async () => {
    const key = $('dg-license-input').value.trim();
    if (!key) return;

    const msgEl = $('dg-license-msg');
    msgEl.textContent = 'Activating...';
    msgEl.style.color = '#71717a';

    // Get or create persistent instance ID
    let data = await chrome.storage.local.get('dg_instance_id');
    let instanceId = data.dg_instance_id;
    if (!instanceId) {
      instanceId = crypto.randomUUID();
      await chrome.storage.local.set({ dg_instance_id: instanceId });
    }

    const resp = await new Promise(resolve => {
      chrome.runtime.sendMessage({
        type: 'activate-license',
        licenseKey: key,
        instanceId: instanceId,
      }, resolve);
    });

    if (resp && resp.ok && resp.data && resp.data.activated) {
      isPro = true;
      const storeInstanceId = resp.data.instance ? resp.data.instance.id : instanceId;
      await chrome.storage.sync.set({
        dg_license_key: key,
        dg_instance_id: storeInstanceId,
        dg_license_valid: true,
        dg_license_checked: Date.now(),
      });
      msgEl.textContent = '';
      updateProUI();
      toast('Pro unlocked!');
    } else {
      const errMsg = (resp && resp.data && resp.data.error) || 'Invalid key or activation limit reached.';
      msgEl.textContent = errMsg;
      msgEl.style.color = '#ef4444';
    }
  });

  // Deactivate button
  $('dg-deactivate').addEventListener('click', async () => {
    const stored = await chrome.storage.sync.get(['dg_license_key', 'dg_instance_id']);
    if (!stored.dg_license_key) return;

    const resp = await new Promise(resolve => {
      chrome.runtime.sendMessage({
        type: 'deactivate-license',
        licenseKey: stored.dg_license_key,
        instanceId: stored.dg_instance_id,
      }, resolve);
    });

    if (resp && resp.ok && resp.data && resp.data.deactivated) {
      isPro = false;
      await chrome.storage.sync.remove(['dg_license_key', 'dg_instance_id', 'dg_license_valid', 'dg_license_checked']);
      updateProUI();
      toast('License deactivated');
    } else {
      toast('Deactivation failed');
    }
  });

  // ── Extract ──
  function extractTokens() {
    const colorMap = {};
    const fontMap = {};
    const spacingMap = {};
    const allElements = document.querySelectorAll('body *:not(#designgrab-host):not(#designgrab-host *)');
    const MAX = 2000;
    let scanned = 0;

    for (const el of allElements) {
      if (scanned >= MAX) break;
      const rect = el.getBoundingClientRect();
      if (!rect.width || !rect.height) continue;
      let cs;
      try { cs = getComputedStyle(el); } catch(e) { continue; }
      if (cs.display === 'none' || cs.visibility === 'hidden') continue;
      scanned++;

      ['color','backgroundColor','borderTopColor','borderBottomColor'].forEach(prop => {
        const val = cs[prop];
        if (!val || val === 'rgba(0, 0, 0, 0)' || val === 'transparent') return;
        const hex = rgbToHex(val);
        if (hex) colorMap[hex] = (colorMap[hex] || 0) + 1;
      });

      const boxShadow = cs.boxShadow;
      if (boxShadow && boxShadow !== 'none') {
        (boxShadow.match(/rgba?\([^)]+\)/g) || []).forEach(sc => {
          const hex = rgbToHex(sc);
          if (hex) colorMap[hex] = (colorMap[hex] || 0) + 1;
        });
      }

      const family = cs.fontFamily.split(',')[0].trim().replace(/['"]/g, '');
      if (!fontMap[family]) fontMap[family] = { sizes: {}, weights: {}, count: 0 };
      fontMap[family].sizes[cs.fontSize] = (fontMap[family].sizes[cs.fontSize] || 0) + 1;
      fontMap[family].weights[cs.fontWeight] = (fontMap[family].weights[cs.fontWeight] || 0) + 1;
      fontMap[family].count++;

      ['paddingTop','paddingRight','paddingBottom','paddingLeft',
       'marginTop','marginRight','marginBottom','marginLeft','gap'].forEach(prop => {
        const val = cs[prop];
        if (!val || val === '0px' || val === 'auto' || val === 'normal') return;
        const px = Math.round(parseFloat(val));
        if (px > 0 && px <= 256) spacingMap[px] = (spacingMap[px] || 0) + 1;
      });
    }

    // Cluster colors
    function hexDist(h1, h2) {
      const [r1,g1,b1] = [h1.slice(1,3),h1.slice(3,5),h1.slice(5,7)].map(x => parseInt(x,16));
      const [r2,g2,b2] = [h2.slice(1,3),h2.slice(3,5),h2.slice(5,7)].map(x => parseInt(x,16));
      return Math.sqrt((r1-r2)**2 + (g1-g2)**2 + (b1-b2)**2);
    }

    const raw = Object.entries(colorMap).map(([hex,count]) => ({hex,count})).sort((a,b) => b.count - a.count);
    const colors = [];
    for (const c of raw) {
      let merged = false;
      for (const cl of colors) {
        if (hexDist(c.hex, cl.hex) < 25) { cl.count += c.count; merged = true; break; }
      }
      if (!merged) colors.push({...c});
    }
    colors.sort((a,b) => b.count - a.count);

    const fonts = Object.entries(fontMap)
      .map(([family, d]) => ({
        family,
        sizes: Object.keys(d.sizes).sort((a,b) => parseFloat(b)-parseFloat(a)),
        weights: [...new Set(Object.keys(d.weights))].sort(),
        count: d.count,
      }))
      .sort((a,b) => b.count - a.count);

    const spacings = Object.keys(spacingMap).map(Number).sort((a,b) => a-b)
      .filter((v,i,arr) => i === 0 || v - arr[i-1] >= 2);

    return { colors, fonts, spacings, hostname: location.hostname, scanned };
  }

  // ── Render ──
  function render(data) {
    $('dg-loading').style.display = 'none';
    $('dg-results').style.display = 'block';
    $('dg-site').textContent = data.hostname + ' · ' + data.scanned + ' elements';
    $('dg-color-count').textContent = data.colors.length + ' unique';
    $('dg-font-count').textContent = data.fonts.length + ' families';
    $('dg-spacing-count').textContent = data.spacings.length + ' values';

    // Colors
    const pal = $('dg-palette');
    data.colors.slice(0, 28).forEach(c => {
      const sw = document.createElement('div');
      sw.className = 'swatch';
      sw.style.backgroundColor = c.hex;
      const [r,g,b] = [c.hex.slice(1,3),c.hex.slice(3,5),c.hex.slice(5,7)].map(x => parseInt(x,16));
      if ((0.299*r + 0.587*g + 0.114*b)/255 > 0.85) sw.style.borderColor = '#52525b';

      const lbl = document.createElement('span');
      lbl.className = 'swatch-label';
      lbl.textContent = c.hex + ' · ' + c.count + 'x';
      sw.appendChild(lbl);

      sw.addEventListener('mouseenter', () => {
        const liveCount = highlightColor(c.hex);
        lbl.textContent = c.hex + ' · ' + liveCount + ' elements';
      });
      sw.addEventListener('mouseleave', () => {
        clearAllHighlights();
        lbl.textContent = c.hex + ' · ' + c.count + 'x';
      });
      sw.addEventListener('click', () => {
        navigator.clipboard.writeText(c.hex).then(() => toast('Copied: ' + c.hex));
      });
      pal.appendChild(sw);
    });

    // Fonts
    const fl = $('dg-fonts');
    data.fonts.slice(0, 8).forEach(f => {
      const item = document.createElement('div');
      item.className = 'font-item';
      const nm = document.createElement('div');
      nm.className = 'font-name';
      nm.textContent = f.family;
      nm.addEventListener('click', () => {
        navigator.clipboard.writeText(f.family).then(() => toast('Copied: ' + f.family));
      });
      const meta = document.createElement('div');
      meta.className = 'font-meta';
      meta.innerHTML = '<span>' + f.sizes.slice(0,5).join(' ') + '</span><span>w: ' + f.weights.join(' ') + '</span>';
      item.appendChild(nm);
      item.appendChild(meta);
      fl.appendChild(item);
    });

    // Spacing
    const sp = $('dg-spacing');
    data.spacings.slice(0, 18).forEach(v => {
      const chip = document.createElement('span');
      chip.className = 'spacing-chip';
      chip.textContent = v + 'px';
      chip.addEventListener('click', () => {
        navigator.clipboard.writeText(v + 'px').then(() => toast('Copied: ' + v + 'px'));
      });
      sp.appendChild(chip);
    });

    // Exports (Pro-gated)
    $('dg-css').addEventListener('click', () => {
      if (!isPro) { toast('Pro feature — activate a license key'); return; }
      let css = '/* Design tokens from ' + data.hostname + ' */\n:root {\n';
      data.colors.slice(0,20).forEach((c,i) => { css += '  --color-' + (i+1) + ': ' + c.hex + ';\n'; });
      css += '\n';
      data.fonts.slice(0,4).forEach(f => {
        css += '  --font-' + f.family.toLowerCase().replace(/\s+/g,'-') + ": '" + f.family + "', sans-serif;\n";
      });
      css += '\n';
      data.spacings.slice(0,12).forEach(v => { css += '  --space-' + v + ': ' + v + 'px;\n'; });
      css += '}\n';
      navigator.clipboard.writeText(css).then(() => toast('CSS Variables copied!'));
    });

    $('dg-tailwind').addEventListener('click', () => {
      if (!isPro) { toast('Pro feature — activate a license key'); return; }
      const cfg = { theme: { extend: { colors: {}, fontFamily: {}, spacing: {} } } };
      data.colors.slice(0,20).forEach((c,i) => { cfg.theme.extend.colors['brand-'+(i+1)] = c.hex; });
      data.fonts.slice(0,4).forEach(f => {
        cfg.theme.extend.fontFamily[f.family.toLowerCase().replace(/\s+/g,'-')] = ["'"+f.family+"'", 'sans-serif'];
      });
      data.spacings.slice(0,12).forEach(v => { cfg.theme.extend.spacing[v] = v+'px'; });
      navigator.clipboard.writeText('// Tailwind config from ' + data.hostname + '\nmodule.exports = ' + JSON.stringify(cfg,null,2) + '\n')
        .then(() => toast('Tailwind config copied!'));
    });

    $('dg-json').addEventListener('click', () => {
      if (!isPro) { toast('Pro feature — activate a license key'); return; }
      const out = {
        source: data.hostname,
        extractedAt: new Date().toISOString(),
        colors: data.colors.slice(0,30).map(c => c.hex),
        typography: data.fonts.slice(0,6).map(f => ({ family: f.family, sizes: f.sizes, weights: f.weights })),
        spacing: data.spacings,
      };
      navigator.clipboard.writeText(JSON.stringify(out,null,2)).then(() => toast('JSON copied!'));
    });

    updateProUI();
  }

  // ── Go ──
  setTimeout(() => {
    const data = extractTokens();
    render(data);
    checkLicense();
  }, 100);

})();
