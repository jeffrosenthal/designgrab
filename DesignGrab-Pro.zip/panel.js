(function() {
  'use strict';

  // ── Toggle: click again to close ──
  const existing = document.getElementById('designgrab-host');
  if (existing) {
    clearAllHighlights();
    existing.remove();
    document.body.style.marginRight = '';
    return;
  }

  // ── Create host + shadow DOM (isolates styles from page) ──
  const host = document.createElement('div');
  host.id = 'designgrab-host';
  host.style.cssText = 'position:fixed;top:0;right:0;width:360px;height:100vh;z-index:2147483647;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;';
  document.body.appendChild(host);
  document.body.style.marginRight = '360px';

  const shadow = host.attachShadow({ mode: 'closed' });

  // ── Styles ──
  const style = document.createElement('style');
  style.textContent = `
    * { margin:0; padding:0; box-sizing:border-box; }
    :host { all: initial; }
    .panel {
      width: 360px; height: 100vh; overflow-y: auto;
      background: #0f0f0f; color: #e4e4e7;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-size: 13px; line-height: 1.5;
      border-left: 1px solid #27272a;
    }
    .panel::-webkit-scrollbar { width: 5px; }
    .panel::-webkit-scrollbar-thumb { background: #3f3f46; border-radius: 3px; }

    .header {
      padding: 14px 16px; border-bottom: 1px solid #27272a;
      display: flex; align-items: center; justify-content: space-between;
      position: sticky; top: 0; background: #0f0f0f; z-index: 10;
    }
    .header-left h1 { font-size: 14px; font-weight: 700; color: #fff; }
    .header-left .site { font-size: 10px; color: #52525b; margin-top: 1px; }
    .close-btn {
      width: 28px; height: 28px; background: #1c1c1e; border: 1px solid #27272a;
      border-radius: 6px; color: #71717a; font-size: 16px; cursor: pointer;
      display: flex; align-items: center; justify-content: center; transition: all 0.15s;
    }
    .close-btn:hover { background: #27272a; color: #fff; }

    .section { padding: 12px 16px; border-bottom: 1px solid #1c1c1e; }
    .section-head {
      display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;
    }
    .section-title {
      font-size: 10px; font-weight: 700; text-transform: uppercase;
      letter-spacing: 0.8px; color: #52525b;
    }
    .section-count { font-size: 10px; color: #3f3f46; }

    .palette { display: flex; flex-wrap: wrap; gap: 5px; }
    .swatch {
      width: 36px; height: 36px; border-radius: 6px; cursor: pointer;
      border: 1px solid #27272a; position: relative;
      transition: transform 0.12s, box-shadow 0.12s;
    }
    .swatch:hover {
      transform: scale(1.2); box-shadow: 0 4px 16px rgba(0,0,0,0.5); z-index: 10;
    }
    .swatch-label {
      position: absolute; bottom: -16px; left: 50%; transform: translateX(-50%);
      font-size: 8px; color: #52525b; white-space: nowrap;
      opacity: 0; transition: opacity 0.12s; pointer-events: none;
    }
    .swatch:hover .swatch-label { opacity: 1; }

    .font-item { padding: 6px 0; border-bottom: 1px solid #1c1c1e; }
    .font-item:last-child { border-bottom: none; }
    .font-name {
      font-size: 13px; font-weight: 600; color: #fff; cursor: pointer;
    }
    .font-name:hover { color: #a78bfa; }
    .font-meta { font-size: 10px; color: #3f3f46; margin-top: 2px; }
    .font-meta span {
      background: #1c1c1e; padding: 1px 5px; border-radius: 3px; margin-right: 4px;
    }

    .spacing-row { display: flex; flex-wrap: wrap; gap: 4px; }
    .spacing-chip {
      background: #1c1c1e; border: 1px solid #27272a; border-radius: 4px;
      padding: 3px 7px; font-size: 10px; font-family: monospace;
      color: #71717a; cursor: pointer; transition: background 0.12s;
    }
    .spacing-chip:hover { background: #27272a; color: #fff; }

    .export-section { padding: 12px 16px; }
    .export-buttons { display: flex; gap: 6px; }
    .export-btn {
      flex: 1; padding: 8px 0; background: #1c1c1e; border: 1px solid #27272a;
      border-radius: 6px; color: #a1a1aa; font-size: 10px; font-weight: 600;
      cursor: pointer; text-align: center; transition: all 0.12s;
    }
    .export-btn:hover { background: #27272a; border-color: #a78bfa; color: #fff; }

    .toast {
      position: fixed; bottom: 16px; left: 50%; transform: translateX(-50%) translateY(30px);
      background: #a78bfa; color: #000; font-size: 11px; font-weight: 600;
      padding: 5px 14px; border-radius: 16px; opacity: 0;
      transition: all 0.2s ease; pointer-events: none; z-index: 100;
    }
    .toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }

    .loading {
      display: flex; flex-direction: column; align-items: center;
      justify-content: center; padding: 80px 20px; gap: 10px;
    }
    .spinner {
      width: 20px; height: 20px; border: 2px solid #27272a;
      border-top: 2px solid #a78bfa; border-radius: 50%;
      animation: spin 0.6s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    .loading-text { font-size: 11px; color: #52525b; }

    .hint {
      padding: 8px 16px; font-size: 10px; color: #3f3f46;
      text-align: center; border-top: 1px solid #1c1c1e;
    }
  `;
  shadow.appendChild(style);

  // ── Panel HTML ──
  const panel = document.createElement('div');
  panel.className = 'panel';
  panel.innerHTML = `
    <div class="loading" id="dg-loading">
      <div class="spinner"></div>
      <div class="loading-text">Scanning page...</div>
    </div>
    <div id="dg-results" style="display:none">
      <div class="header">
        <div class="header-left">
          <h1>DesignGrab</h1>
          <div class="site" id="dg-site"></div>
        </div>
        <button class="close-btn" id="dg-close">&times;</button>
      </div>
      <div class="section">
        <div class="section-head">
          <div class="section-title">Colors</div>
          <div class="section-count" id="dg-color-count"></div>
        </div>
        <div class="palette" id="dg-palette"></div>
      </div>
      <div class="section">
        <div class="section-head">
          <div class="section-title">Typography</div>
          <div class="section-count" id="dg-font-count"></div>
        </div>
        <div id="dg-fonts"></div>
      </div>
      <div class="section">
        <div class="section-head">
          <div class="section-title">Spacing</div>
          <div class="section-count" id="dg-spacing-count"></div>
        </div>
        <div class="spacing-row" id="dg-spacing"></div>
      </div>
      <div class="export-section">
        <div class="export-buttons">
          <button class="export-btn" id="dg-css">CSS Vars</button>
          <button class="export-btn" id="dg-tailwind">Tailwind</button>
          <button class="export-btn" id="dg-json">JSON</button>
        </div>
      </div>
      <div class="hint">Hover a color to highlight on page. Click to copy.</div>
    </div>
    <div class="toast" id="dg-toast">Copied!</div>
  `;
  shadow.appendChild(panel);

  // ── Refs ──
  const $ = (id) => shadow.getElementById(id);

  // ── Close ──
  $('dg-close').addEventListener('click', () => {
    clearAllHighlights();
    host.remove();
    document.body.style.marginRight = '';
  });

  // ── Toast ──
  function toast(msg) {
    const t = $('dg-toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 1200);
  }

  // ── Highlight helpers ──
  function rgbToHex(rgb) {
    const m = rgb.match(/rgba?\(\s*(\d+),\s*(\d+),\s*(\d+)/);
    if (!m) return null;
    const r = parseInt(m[1]), g = parseInt(m[2]), b = parseInt(m[3]);
    return '#' + [r,g,b].map(x => x.toString(16).padStart(2,'0')).join('');
  }

  function highlightColor(hex) {
    clearAllHighlights();
    const els = document.querySelectorAll('body *:not(#designgrab-host):not(#designgrab-host *)');
    for (const el of els) {
      try {
        const cs = getComputedStyle(el);
        const bg = rgbToHex(cs.backgroundColor);
        const fg = rgbToHex(cs.color);
        const bd = rgbToHex(cs.borderTopColor);
        if (bg === hex || fg === hex || bd === hex) {
          el.setAttribute('data-dg-hl', '1');
          el.style.outline = '3px solid #a78bfa';
          el.style.outlineOffset = '2px';
        }
      } catch(e) {}
    }
  }

  function clearAllHighlights() {
    document.querySelectorAll('[data-dg-hl]').forEach(el => {
      el.style.outline = '';
      el.style.outlineOffset = '';
      el.removeAttribute('data-dg-hl');
    });
  }

  // ── Extract ──
  function extractTokens() {
    const colorMap = {};
    const fontMap = {};
    const spacingMap = {};
    const allElements = document.querySelectorAll('body *:not(#designgrab-host):not(#designgrab-host *)');
    const MAX = 2000;
    let scanned = 0;

    for (const el of allElements) {
      if (scanned >= MAX) break;
      const rect = el.getBoundingClientRect();
      if (!rect.width || !rect.height) continue;
      let cs;
      try { cs = getComputedStyle(el); } catch(e) { continue; }
      if (cs.display === 'none' || cs.visibility === 'hidden') continue;
      scanned++;

      ['color','backgroundColor','borderTopColor','borderBottomColor'].forEach(prop => {
        const val = cs[prop];
        if (!val || val === 'rgba(0, 0, 0, 0)' || val === 'transparent') return;
        const hex = rgbToHex(val);
        if (hex) colorMap[hex] = (colorMap[hex] || 0) + 1;
      });

      const shadow = cs.boxShadow;
      if (shadow && shadow !== 'none') {
        (shadow.match(/rgba?\([^)]+\)/g) || []).forEach(sc => {
          const hex = rgbToHex(sc);
          if (hex) colorMap[hex] = (colorMap[hex] || 0) + 1;
        });
      }

      const family = cs.fontFamily.split(',')[0].trim().replace(/['"]/g, '');
      if (!fontMap[family]) fontMap[family] = { sizes: {}, weights: {}, count: 0 };
      fontMap[family].sizes[cs.fontSize] = (fontMap[family].sizes[cs.fontSize] || 0) + 1;
      fontMap[family].weights[cs.fontWeight] = (fontMap[family].weights[cs.fontWeight] || 0) + 1;
      fontMap[family].count++;

      ['paddingTop','paddingRight','paddingBottom','paddingLeft',
       'marginTop','marginRight','marginBottom','marginLeft','gap'].forEach(prop => {
        const val = cs[prop];
        if (!val || val === '0px' || val === 'auto' || val === 'normal') return;
        const px = Math.round(parseFloat(val));
        if (px > 0 && px <= 256) spacingMap[px] = (spacingMap[px] || 0) + 1;
      });
    }

    // Cluster colors
    function hexDist(h1, h2) {
      const [r1,g1,b1] = [h1.slice(1,3),h1.slice(3,5),h1.slice(5,7)].map(x => parseInt(x,16));
      const [r2,g2,b2] = [h2.slice(1,3),h2.slice(3,5),h2.slice(5,7)].map(x => parseInt(x,16));
      return Math.sqrt((r1-r2)**2 + (g1-g2)**2 + (b1-b2)**2);
    }

    const raw = Object.entries(colorMap).map(([hex,count]) => ({hex,count})).sort((a,b) => b.count - a.count);
    const colors = [];
    for (const c of raw) {
      let merged = false;
      for (const cl of colors) {
        if (hexDist(c.hex, cl.hex) < 25) { cl.count += c.count; merged = true; break; }
      }
      if (!merged) colors.push({...c});
    }
    colors.sort((a,b) => b.count - a.count);

    const fonts = Object.entries(fontMap)
      .map(([family, d]) => ({
        family,
        sizes: Object.keys(d.sizes).sort((a,b) => parseFloat(b)-parseFloat(a)),
        weights: [...new Set(Object.keys(d.weights))].sort(),
        count: d.count,
      }))
      .sort((a,b) => b.count - a.count);

    const spacings = Object.keys(spacingMap).map(Number).sort((a,b) => a-b)
      .filter((v,i,arr) => i === 0 || v - arr[i-1] >= 2);

    return { colors, fonts, spacings, hostname: location.hostname, scanned };
  }

  // ── Render ──
  function render(data) {
    $('dg-loading').style.display = 'none';
    $('dg-results').style.display = 'block';
    $('dg-site').textContent = data.hostname + ' · ' + data.scanned + ' elements';
    $('dg-color-count').textContent = data.colors.length + ' unique';
    $('dg-font-count').textContent = data.fonts.length + ' families';
    $('dg-spacing-count').textContent = data.spacings.length + ' values';

    // Colors
    const pal = $('dg-palette');
    data.colors.slice(0, 28).forEach(c => {
      const sw = document.createElement('div');
      sw.className = 'swatch';
      sw.style.backgroundColor = c.hex;
      const [r,g,b] = [c.hex.slice(1,3),c.hex.slice(3,5),c.hex.slice(5,7)].map(x => parseInt(x,16));
      if ((0.299*r + 0.587*g + 0.114*b)/255 > 0.85) sw.style.borderColor = '#52525b';

      const lbl = document.createElement('span');
      lbl.className = 'swatch-label';
      lbl.textContent = c.hex;
      sw.appendChild(lbl);

      sw.addEventListener('mouseenter', () => highlightColor(c.hex));
      sw.addEventListener('mouseleave', () => clearAllHighlights());
      sw.addEventListener('click', () => {
        navigator.clipboard.writeText(c.hex).then(() => toast('Copied: ' + c.hex));
      });
      pal.appendChild(sw);
    });

    // Fonts
    const fl = $('dg-fonts');
    data.fonts.slice(0, 8).forEach(f => {
      const item = document.createElement('div');
      item.className = 'font-item';
      const nm = document.createElement('div');
      nm.className = 'font-name';
      nm.textContent = f.family;
      nm.addEventListener('click', () => {
        navigator.clipboard.writeText(f.family).then(() => toast('Copied: ' + f.family));
      });
      const meta = document.createElement('div');
      meta.className = 'font-meta';
      meta.innerHTML = '<span>' + f.sizes.slice(0,5).join(' ') + '</span><span>w: ' + f.weights.join(' ') + '</span>';
      item.appendChild(nm);
      item.appendChild(meta);
      fl.appendChild(item);
    });

    // Spacing
    const sp = $('dg-spacing');
    data.spacings.slice(0, 18).forEach(v => {
      const chip = document.createElement('span');
      chip.className = 'spacing-chip';
      chip.textContent = v + 'px';
      chip.addEventListener('click', () => {
        navigator.clipboard.writeText(v + 'px').then(() => toast('Copied: ' + v + 'px'));
      });
      sp.appendChild(chip);
    });

    // Exports
    $('dg-css').addEventListener('click', () => {
      let css = '/* Design tokens from ' + data.hostname + ' */\n:root {\n';
      data.colors.slice(0,20).forEach((c,i) => { css += '  --color-' + (i+1) + ': ' + c.hex + ';\n'; });
      css += '\n';
      data.fonts.slice(0,4).forEach(f => {
        css += '  --font-' + f.family.toLowerCase().replace(/\s+/g,'-') + ": '" + f.family + "', sans-serif;\n";
      });
      css += '\n';
      data.spacings.slice(0,12).forEach(v => { css += '  --space-' + v + ': ' + v + 'px;\n'; });
      css += '}\n';
      navigator.clipboard.writeText(css).then(() => toast('CSS Variables copied!'));
    });

    $('dg-tailwind').addEventListener('click', () => {
      const cfg = { theme: { extend: { colors: {}, fontFamily: {}, spacing: {} } } };
      data.colors.slice(0,20).forEach((c,i) => { cfg.theme.extend.colors['brand-'+(i+1)] = c.hex; });
      data.fonts.slice(0,4).forEach(f => {
        cfg.theme.extend.fontFamily[f.family.toLowerCase().replace(/\s+/g,'-')] = ["'"+f.family+"'", 'sans-serif'];
      });
      data.spacings.slice(0,12).forEach(v => { cfg.theme.extend.spacing[v] = v+'px'; });
      navigator.clipboard.writeText('// Tailwind config from ' + data.hostname + '\nmodule.exports = ' + JSON.stringify(cfg,null,2) + '\n')
        .then(() => toast('Tailwind config copied!'));
    });

    $('dg-json').addEventListener('click', () => {
      const out = {
        source: data.hostname,
        extractedAt: new Date().toISOString(),
        colors: data.colors.slice(0,30).map(c => c.hex),
        typography: data.fonts.slice(0,6).map(f => ({ family: f.family, sizes: f.sizes, weights: f.weights })),
        spacing: data.spacings,
      };
      navigator.clipboard.writeText(JSON.stringify(out,null,2)).then(() => toast('JSON copied!'));
    });
  }

  // ── Go ──
  setTimeout(() => {
    const data = extractTokens();
    render(data);
  }, 100);

})();
