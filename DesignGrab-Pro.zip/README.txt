DesignGrab Pro — Quick Setup
============================

1. Open Chrome → chrome://extensions
2. Turn on "Developer Mode" (top right toggle)
3. Click "Load unpacked" → select this folder
4. Visit any website and click the DesignGrab icon in your toolbar
5. Enter your license key in the sidebar to unlock exports

Your license key was emailed to you by LemonSqueezy after purchase.
Lost it? Check your email or visit your LemonSqueezy customer portal.

Need help? Email jeff@thecodingpit.com
